import { PokemonService } from '../services/pokemon/pokemon.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  regioes: any[] = [];

  constructor(
    private pkmServ: PokemonService,
    private rota: Router
  ) {
    console.log('Constructor');
  }

  mostrarDetalhes(url: string){
    this.pkmServ.setUrl(url);

    this.rota.navigateByUrl('/detalhes');
  }

  ngOnInit(){
    console.log('ngOnInit');
    this.pkmServ.buscarRegioes().subscribe(
      dados => {
        console.log(dados);
        this.regioes = dados.results;
      },
      erro => {
        console.error(erro);
      }
    );
  }
}
