import { PokemonService } from '../services/pokemon/pokemon.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalhes',
  templateUrl: './detalhes.page.html',
  styleUrls: ['./detalhes.page.scss'],
})
export class DetalhesPage implements OnInit {
  pokemons: any[] = [];
  regiao = '';

  constructor(
    private pknServ: PokemonService
  ){ }

  ngOnInit() {
    this.loadData();
  }

  loadData(){
    this.pknServ.buscarPokemons().subscribe(
      (dados) => {
        console.log(dados);
        if(dados.region !== null){
          this.regiao = dados.region.name;
        }else{
          this.regiao = dados.names[2].name;
        }

        this.pokemons = dados.pokemon_entries;
        console.log(this.pokemons);
      },
      (erro) => {
        console.error(erro);
      }
    );
  }

}
