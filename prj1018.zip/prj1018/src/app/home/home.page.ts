import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  display = '';
  memoria = null;

  constructor() {}

  clicar(numero: string){
    this.display= this.display + numero;
  }

  ponto(){
    if(this.display === ''){
      this.display = '';
    }
    else if(this.display === '.'){
      this.display = '';
    }
    else{
      this.display = this.display + '.';
    }
  }

  soma(){
    if (this.memoria == null) {
      this.memoria = this.display;
    }
    else{
      this.memoria = this.memoria + parseFloat(this.display);
    }
    this.limpar();
  }

  subtracao(){
    if (this.memoria == null) {
      this.memoria = this.display;
    }
    else{
      this.memoria = this.memoria - parseFloat(this.display);
    }
    this.limpar();
  }

  multiplicacao(){
    if (this.memoria == null) {
      this.memoria = this.display;
    }
    else{
      this.memoria = this.memoria * parseFloat(this.display);
    }
    this.limpar();
  }

  divisao(){
    if (this.memoria == null) {
      this.memoria = this.display;
    }
    else{
      this.memoria = this.memoria / parseFloat(this.display);
    }
    this.limpar();
  }

  igual(){
    if(this.memoria != null){
      this.display = this.memoria;
    }
  }

  limpar(){
    this.display = '';
  }

}
