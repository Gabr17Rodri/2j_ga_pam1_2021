import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  pG = null;
  pE = null;
  verificar = '';
  resposta = "";

  combustiveis = [
    'gasolina.jpg',
    'etanol.jpg',
    'gasolina_ou_etanol.jpg'
  ]

  combustivel = 'gaso_eno.jpg'

  constructor() {}

  dividir(indice: number): void{
    let d = this.pE / this.pG;
    this.verificar = d.toFixed(2).toString();
    if(d > 0.7)
    {
      this.resposta = "A Gasolina é mais vantajosa!";
      this.combustivel = this.combustiveis[0];
    }
    else if(d < 0.7)
    {
      this.resposta = "O Etanol é mais vantajosa!"
      this.combustivel = this.combustiveis[1]
    }
    else
    {
      this.resposta = "Você que decidi!"
      this.combustivel = this.combustiveis[2]
    }
  }
}
