import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PokemonService {
  url = '';

  constructor(
    private http: HttpClient
  ) {}

  setUrl(url: string){
    this.url = url;
  }

  buscarRegioes(): Observable<any>{
    return this.http.get<any>('https://pokeapi.co/api/v2/pokedex').pipe(
      map(regioes => {
        console.log('Regiões localizadas');
        return regioes;
      }),
      catchError(erro => erro)
    );
  }

  buscarPokemons(): Observable<any>{
    return this.http.get<any>(this.url).pipe(
      map(regioes => {
        console.log('Pokemons localizados');
        return regioes;
      }),
      catchError(erro => erro)
    );
  }
}
